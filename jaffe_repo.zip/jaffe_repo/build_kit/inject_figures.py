#!/usr/bin/env python3
"""
inject_figures.py — inline figures/figures.json into index.html as window.__FIGURES__.
Run after extract_figures.py (which writes figures/ + figures.json) and after the
PROCEDURES array is updated. Idempotent: replaces any prior injection.

Usage:
    python3 inject_figures.py index.html figures/figures.json
"""
import json, re, sys, pathlib
html_path = pathlib.Path(sys.argv[1] if len(sys.argv)>1 else "index.html")
man_path  = pathlib.Path(sys.argv[2] if len(sys.argv)>2 else "figures/figures.json")
html = html_path.read_text()
manifest = json.load(open(man_path))
slim = {sid:[{k:e.get(k) for k in ("file","caption","bookPage","figref")} for e in figs]
        for sid,figs in manifest.items()}
inject = "window.__FIGURES__ = " + json.dumps(slim, separators=(",",":")) + ";\n"
html = re.sub(r"window\.__FIGURES__ = .*?;\n", "", html, flags=re.DOTALL)
html = html.replace("const PROCEDURES = [", inject + "const PROCEDURES = [", 1)
html_path.write_text(html)
print(f"injected {sum(len(v) for v in slim.values())} figures across {len(slim)} section(s)")
